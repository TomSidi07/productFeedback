import FeedbackView from "./createFeedbackView.js";

let suggestionCont = document.querySelector(".suggestion__content");
let btn__addFeedback = document.querySelector(".btn--add-feedback");
let btnCancel = document.querySelector(".btn--cancel");
let btnaddFeedback = document.querySelector(".add-feedback");
let IdCount;
let popup = document.querySelector(".popup");
// console.log(btn__addFeedback);
// console.log(popup);
let url = "/data.json";
let feedbackList;
//******************************************************************************************** */ Resquest Data
async function request() {
  try {
    await fetch(url || "")
      .then((req) => {
        return req.json();
      })
      .then((response) => {
        try {
          feedbackList = [...response.productRequests];
          upDateUI(feedbackList);
          IdCount = feedbackList.length;
          IdCount++;
          if (btn__addFeedback)
            btn__addFeedback.addEventListener("click", (event) => {
              let addFeedback = document.querySelector(".add-feedback");

              event.preventDefault();
              popup.classList.toggle("active");
              if (btnCancel)
                btnCancel.addEventListener("click", (eve) => {
                  event.preventDefault();
                  // addFeedBack(feedbackList);
                  popup.classList.remove("active");
                });
            });
        } catch (error) {
          console.log(error);
        }
      })
      .catch((err) => {
        console.log(err);
      });
  } catch (error) {
    console.log(error);
  }
}
// console.log(feedbackList);
// Add new feedback
class FeedBack {
  id;
  title;
  category;
  upvotes;
  status;
  comments;
  description;
  constructor(title, category, upvotes, status, comments = undefined) {
    this.id = IdCount++;
    this.comments = comments;
    this.category = category;
    this.status = status;
    this.title = title;
    this.upvotes = upvotes;
  }
}
let testFeedBack = new FeedBack(1, "Tom is the best", "Tom tom", 999, "BEST");
let test;
function addFeedBack() {
  feedbackList.push(testFeedBack /* input values */);

  upDateUI(feedbackList);
}
// Update the suggestion content bloc
async function upDateUI(response) {
  (function cleanSuggestCont() {
    (suggestionCont || "").innerHTML = "";
  })();
  await response.forEach((data) => {
    let suggestion__card__code = `<div class="left">
       
              <a href="#"><btn class="pan">${data.upvotes}</btn></a>
            </div>
            <div class="right">
              <div class="header">
                <h2>${data.title}</h2>
              </div>
              <div class="content">
                <p>
                  ${data.description}
                </p>
               <a href="#"> <btn class="pan">${data.category}</btn></a>
              </div>
            </div>`;
    let suggestionHtml = document.createElement("div");
    suggestionHtml.innerHTML = suggestion__card__code;
    suggestionHtml.classList.add("card--suggestion-content", "card");
    if (suggestionCont) suggestionCont.appendChild(suggestionHtml);
    // console.log(data.productRequests[0]);
  });
}


function createFeedback() {
  console.log("Add");
  let { title, category, comment } = FeedbackView;
  let newFeedback = new FeedBack(55, title, category, 152, "publish", comment);
  feedbackList.push(newFeedback);
  console.log(newFeedback);
  FeedbackView.render(newFeedback);
  addtoLs(newFeedback);
  // console.log(btnaddFeedback);
  // if (btnaddFeedback) {
  //   btnaddFeedback.addEventListener("click", () => {
  //     // console.log("click")
  //   });
  // }
}
function addtoLs(feedback) {
  let data = getFromLs(feedback.id);
  if (Array.isArray(data)) {
    data.push(feedback);
    localStorage.setItem(feedback.id, JSON.stringify(data));
  }
  return;
}
function getFromLs(feedbackID) {
  return localStorage.getItem(JSON.parse(feedbackID) || "[]");
}
let init = () => {
  FeedbackView.Handler(createFeedback);
  // FeedbackView.render();
  request();
};
init();
